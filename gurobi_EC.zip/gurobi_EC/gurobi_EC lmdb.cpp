#include "gurobi_c++.h"
#include "bits/stdc++.h"
#include "math.h"
#include <queue>
using namespace std;

vector<vector<int>> e = { 
    //default
    {1, 0}, 
    {1, 0},
    {1, 0}, 
    {1, 0}, 
    {1, 0}, 
    {1, 1}, 
    {0, 1}, 
    {0, 1}, 
    {0, 1}, 
    {0, 1}, 
    {0, 0}, 
    {0, 0},
//     //bangdrug single
//     {1}, 
//     {1}, 
//     {1},  
//     {1},  
//     {1},  
//     {1}, 
//     {1}, 
//     {1},  
//     {1},  
//     {1},  
//     {1},  
//     {0}, 
}; 
// //bangdrug 3ES
// vector<vector<int>> e = { 
//     {1, 0, 1}, 
//     {1, 0, 1},
//     {1, 0, 1}, 
//     {1, 0, 1}, 
//     {1, 0, 1}, 
//     {1, 1, 1}, 
//     {0, 1, 1}, 
//     {0, 1, 1}, 
//     {0, 1, 1}, 
//     {0, 1, 1}, 
//     {0, 1, 1}, 
//     {0, 0, 0},
// }; 
//bangdrug 4ES
// vector<vector<int>> e = { 
//     {1, 0, 1, 1}, 
//     {1, 0, 1, 1},
//     {1, 0, 1, 1}, 
//     {1, 0, 1, 1}, 
//     {1, 0, 1, 1}, 
//     {1, 1, 1, 1}, 
//     {0, 1, 1, 1}, 
//     {0, 1, 1, 1}, 
//     {0, 1, 1, 1}, 
//     {0, 1, 1, 1}, 
//     {0, 1, 1, 1}, 
//     {0, 0, 0, 0},
// }; 
vector<double> c = {191, 146, 123, 207, 214, 152, 202, 186, 262, 258, 1137, 3974}; //lmdb time now

vector<double> F = {200, 200}; // CPU cycles per second 0.2GHZ (200MHz)
// vector<double> F = {400, 400}; // CPU cycles per second 0.4GHZ
// vector<double> F = {600, 600}; // CPU cycles per second 0.6GHZ
// vector<double> F = {800, 800}; // CPU cycles per second 0.8GHZ
// vector<double> F = {1000, 1000}; // CPU cycles per second 1GHZ
// single
// vector<double> F = {200}; // CPU cycles per second 0.2GHZ
// 3ES
// vector<double> F = {200, 200, 200}; // CPU cycles per second 0.2GHZ
// vector<double> F = {200, 200, 200, 200}; // CPU cycles per second 0.2GHZ



// vector<double> w = {21, 57, 2535, 474, 3105, 579, 30, 21, 6, 0, 180, 3};  //bangdurg N-triple result size
vector<double> w = {25939, 9214, 411078, 82647, 491968, 83141, 6109, 4978, 1392, 210, 28930, 822};  //lmdb Query result size byte

// double r_nk_e = 70.0; 
// double r_nk_c = 6.0; 
// now
double r_nk_e = 210.0;
// double r_nk_e = 180.0;
// double r_nk_e = 150.0;
// double r_nk_e = 120.0;
// double r_nk_e = 90.0;
// double r_nk_e = 60.0;
// double r_nk_e = 30.0;


double r_nk_c = 21.0; 
int n = 12; 

int k = 2; 
// int k = 1; 
// int k = 3; 
// int k = 4; 

struct node
{
     /* data */
     double upper;
     double lower;
     int Nd_num;
     std::vector<std::vector<int>> d;
     std::vector<std::vector<int>> d_upper;
};
double calcProblem(node &p);
double calcTargetVal(node &p);

int main(int argc,
         char *argv[])
{
     
     queue<node> Q;
     node p;
     p.Nd_num = 0;
     p.d = {};
     p.d_upper.assign(n, vector<int>(k, 0));
     calcTargetVal(p);
     double min_upper = p.upper;
     vector<vector<int>> best_D;
     cout << "min_upper:" << min_upper << endl;
     Q.push(p);
     while (!Q.empty()) 
     {
          p = Q.front();
          Q.pop();
          int index = p.Nd_num;
          if (index >= n)
               break;
          std::vector<std::vector<int>> determinedD = p.d;
          node p_cloud;
          p_cloud.Nd_num = index + 1;
          vector<int> cloud_vector(k, 0); // k  0 auto
          determinedD.push_back(cloud_vector);
          // determinedD.push_back({0, 0});
          p_cloud.d = determinedD;
          calcProblem(p_cloud);
          calcTargetVal(p_cloud);
          if (min_upper > p_cloud.upper)
          {
               min_upper = p_cloud.upper;
               best_D = p_cloud.d_upper;
          }
          vector<node> p_edge;
          for (int i = 0; i < k; i++)
          {
               vector<int> T(k, 0);
               if (e[index][i] == 1)
               {
                    T[i] = 1;
                    node p_e;
                    p_e.Nd_num = index + 1;
                    std::vector<std::vector<int>> determinedD_edge = p.d;
                    determinedD_edge.push_back(T);
                    p_e.d = determinedD_edge;
                    cout << "nd:" << p_e.Nd_num << endl;
                    cout << "dnum:" << determinedD.size() << endl;
                    calcProblem(p_e);
                    calcTargetVal(p_e);
                    if (min_upper > p_e.upper)
                    {
                         min_upper = p_e.upper;
                         best_D = p_e.d_upper;
                    }
                    p_edge.push_back(p_e);
               }
          }
          cout << "************" << endl;
          cout << p_cloud.lower << endl;
          cout << min_upper << endl;

          if (p_cloud.lower <= min_upper)
               Q.push(p_cloud);
          for (int i = 0; i < p_edge.size(); i++)
          {
               if (p_edge[i].lower <= min_upper)
                    Q.push(p_edge[i]);
          }
          cout << "Q_num" << Q.size() << endl;
     }
     cout << "bestD: " << endl;
     for (int i = 0; i < n; i++)
     {
          for (int j = 0; j < k; j++)
          {
               cout << best_D[i][j] << " ";
          }
          cout << endl;
     }
     vector<vector<double>> f(n, vector<double>(k));
     vector<double> fm(k);
     for (int i = 0; i < k; i++)
     {
          for (int j = 0; j < n; j++)
          {
               fm[i] += best_D[j][i] * e[j][i] * sqrt(c[j]);
          }
     }
     for (int i = 0; i < n; i++)
     {
          for (int j = 0; j < k; j++)
          {
               if (best_D[i][j] == 0)
               {
                    f[i][j] = 0;
                    cout << f[i][j] << " ";
                    continue;
               }
               f[i][j] = F[j] * sqrt(c[i]) / fm[j];
               cout << f[i][j] << " ";
          }
          cout << endl;
     }
     cout << "bestTarget: " << min_upper << endl;

     return 0;
}

double calcTargetVal(node &p)
{
     std::vector<std::vector<int>> D_upper = p.d_upper;
     double obj = 0.0;
     for (int i = 0; i < k; i++)
     {
          double tmp = 0.0;
          for (int j = 0; j < n; j++)
          {
               tmp += D_upper[j][i] * e[j][i] * sqrt(c[j]);
          }
          obj += tmp * tmp / F[i];
     }
     for (int i = 0; i < k; i++)
     {
          for (int j = 0; j < n; j++)
          {
               obj += D_upper[j][i] * e[j][i] * w[j] / r_nk_e;
          }
     }
     for (int i = 0; i < n; i++)
     {
          int is_edge = 0;
          for (int j = 0; j < k; j++)
          {
               is_edge += D_upper[i][j] * e[i][j];
          }
          if (is_edge == 0)
               obj += w[i] / r_nk_c;
     }
     p.upper = obj;
     return obj;
}

double calcProblem(node &p)
{
     int Nd_num = p.Nd_num;
     std::vector<std::vector<int>> d = p.d;
     GRBEnv *env = nullptr; 
     // Create an environment
     env = new GRBEnv();
     GRBModel model = GRBModel(*env);
     // Create variables
     GRBVar **D = 0;
     int dcnt = 0;

     try
     {
          D = new GRBVar *[n - Nd_num];
          for (int i = 0; i < n - Nd_num; i++)
          {
               D[i] = new GRBVar[k];
               dcnt++;
          }
          for (int i = 0; i < n - Nd_num; i++)
          {
               for (int j = 0; j < k; j++)
               {
                    int tmp = i + Nd_num;
                    // string vname = "D_"+tmp+j;
                    // cout<<tmp<<" "<<j<<" "<<vname<<endl;
                    ostringstream vname;
                    vname << "D_" << tmp << j;
                    D[i][j] = model.addVar(0.0, 1.0, 0.0, GRB_CONTINUOUS, vname.str());
               }
               // D[i] = model.addVars(k, GRB_CONTINUOUS);
          }

          double obj1 = 0.0;
          for (int i = 0; i < k; i++)
          {
               double tmp = 0.0;
               for (int j = 0; j < Nd_num; j++)
               {
                    tmp += d[j][i] * e[j][i] * sqrt(c[j]);
               }
               obj1 += tmp * tmp / F[i];
          }
          for (int i = 0; i < k; i++)
          {
               for (int j = 0; j < Nd_num; j++)
               {
                    obj1 += d[j][i] * e[j][i] * w[j] / r_nk_e;
               }
          }
          for (int i = 0; i < Nd_num; i++)
          {
               int is_edge = 0; 
               for (int j = 0; j < k; j++)
               {
                    is_edge += d[i][j] * e[i][j];
               }
               if (is_edge == 0)
                    obj1 += w[i] / r_nk_c;
          }

          GRBQuadExpr obj2 = 0.0;
          for (int i = 0; i < k; i++)
          {
               GRBLinExpr tmp = 0.0;
               for (int j = 0; j < n - Nd_num; j++)
               {
                    // cout << "----"
                    //      << " " << e[j + Nd_num][i] << " " << sqrt(c[j]) << endl;
                    tmp += D[j][i] * e[j + Nd_num][i] * sqrt(c[j]);
               }
               obj2 += tmp * tmp / F[i];
          }
          GRBLinExpr obj3 = 0.0;
          for (int i = 0; i < k; i++)
          {
               for (int j = 0; j < n - Nd_num; j++)
               {
                    // cout << "----" << e[j + Nd_num][i] << endl;
                    obj3 += D[j][i] * e[j + Nd_num][i] * w[j + Nd_num] / r_nk_e;
               }
          }
          for (int i = 0; i < n - Nd_num; i++)
          {
               GRBLinExpr is_edge = 0.0;
               for (int j = 0; j < k; j++)
               {
                    // cout << "----" << e[i + Nd_num][j] << endl;
                    is_edge += D[i][j] * e[i + Nd_num][j];
               }
               obj3 += (1 - is_edge) * w[i + Nd_num] / r_nk_c;
          }
          if (n == Nd_num)
          {
               cout << "target::::::" << obj1 + obj2 + obj3 << endl;
          }

          model.setObjective(obj1 + obj2 + obj3);

          GRBLinExpr constr1 = 0.0;
          for (int i = 0; i < n - Nd_num; i++)
          {
               GRBLinExpr constr = 0.0;
               ostringstream cname;
               cname << "c" << i;
               for (int j = 0; j < k; j++)
               {
                    constr += D[i][j] * e[i + Nd_num][j];
               }
               model.addConstr(constr <= 1, cname.str());
          }

          // Optimize model
          model.optimize();
          std::vector<std::vector<int>> D_upper = p.d;

          for (int i = 0; i < n - Nd_num; i++)
          {
               std::vector<int> tmp;
               for (int j = 0; j < k; j++)
               {
                    cout << D[i][j].get(GRB_StringAttr_VarName) << " "
                         << D[i][j].get(GRB_DoubleAttr_X) << endl;
                    tmp.push_back(static_cast<int>(round(D[i][j].get(GRB_DoubleAttr_X)))); 
               }
               D_upper.push_back(tmp);
          }

          for (int i = 0; i < n; i++)
          {
               for (int j = 0; j < k; j++)
               {
                    cout << D_upper[i][j] << " ";
               }
               cout << endl;
          }

          cout << "Obj: " << model.get(GRB_DoubleAttr_ObjVal) << endl;
          p.lower = model.get(GRB_DoubleAttr_ObjVal);
          p.d_upper = D_upper;
     }
     catch (GRBException e)
     {
          cout << "Error code = " << e.getErrorCode() << endl;
          cout << e.getMessage() << endl;
     }
     catch (...)
     {
          cout << "Exception during optimization" << endl;
     }
     for (int i = 0; i < dcnt; ++i)
     {
          delete[] D[i];
     }
     delete[] D;
     cout << "----------------------------------" << endl;
     delete env;
     return model.get(GRB_DoubleAttr_ObjVal);
}